/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;

/**
 *
 * @author nquin
 */
public abstract class PrendaComponent {
    public abstract String getRef();
    public abstract String getTipo();
    public abstract double getValorAlquiler();
    public abstract String getInfo();
}
