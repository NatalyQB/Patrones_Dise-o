/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aa4_implementacion;

/**
 *
 * @author nquin
 */
public class AA4_Implementacion {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
