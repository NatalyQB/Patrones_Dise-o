/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.model;
import com.mycompany.observer.ISujeto;
import com.mycompany.observer.IObservador;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author nquin
 */
public abstract class PrendaComponent implements ISujeto {
    protected String referencia;
    protected String tipo;
    protected double valorAlquiler;
    protected String estado;

    private List<IObservador> observadores = new ArrayList<>();

    
    public abstract String getRef();
    public abstract String getTipo();
    public abstract double getValorAlquiler();
    public abstract String getInfo();

    // -------------------
    // manejo de estado con Observer
    // -------------------
    public String getEstado() {
        return estado;
    }

    public void setEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
        // cada vez que cambia el estado se notifican los observadores
        notificarObservadores(nuevoEstado);
    }

    // -------------------
    //  ISujeto
    // -------------------
    @Override
    public void agregarObservador(IObservador obs) {
        if (!observadores.contains(obs)) {
            observadores.add(obs);
        }
    }

    @Override
    public void removerObservador(IObservador obs) {
        observadores.remove(obs);
    }

    @Override
    public void notificarObservadores(String evento) {
        for (IObservador o : new ArrayList<>(observadores)) {
            o.actualizar(this, evento);
        }
    }
}
